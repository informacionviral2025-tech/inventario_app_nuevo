import 'package:flutter/material.dart';

class AlbaranesProveedorScreen extends StatelessWidget {
  const AlbaranesProveedorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Albaranes de Proveedor')),
      body: const Center(child: Text('Aquí irán los albaranes de proveedor')),
    );
  }
}